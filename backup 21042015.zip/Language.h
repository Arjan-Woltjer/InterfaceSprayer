/*
  Language file for sprayercontrol
Copyright (C) 2011-2013 J.A. Woltjer.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef Language_h
#define Language_h

#include <avr/pgmspace.h>

#define NEDERLANDS

// ---------------
// Serial messages
// ---------------
#define S_MEIJWORKS     "MeijWorks"
#define S_DEVICE        "Sprayercontrol v 1.00"
#define S_LIBRARY       "FarmGPS library v "
#define S_COPYRIGHT     "(c) 2011 - 2015 by J.A. Woltjer"
#define S_TIMES         "Times started: "
#define S_DIVIDE        "-------------------------------"

// -----------
// Taal ENGELS TODO
// -----------
#ifdef ENGLISH

#define L_BLANK         "                    "

#define L_MEIJWORKS     "     MeijWorks      "
#define L_DEVICE        " Plantercontrol 1.00"
#define L_COPYRIGHT     "      (c) 2014      "
#define L_AUTHOR        "  by J.A. Woltjer   "

#define L_OFFSET        "Offset:             "
#define L_A_STEER       "Actual position:    "
#define L_SETPOINT      "Setpoint:           "
#define L_ANGLE         "Angle:              "

#define L_CAL_ACCEPT    "+ : accept          "
#define L_CAL_DECLINE   "- : cancel          "

#define L_CAL_DONE      "complete            "
#define L_CAL_DECLINED  "cancelled           "

#define L_CAL_ADJUST    "+ / - : to adjust   "
#define L_CAL_ENTER     "Both  : to accept   "

#define L_CAL_STEER     "Steer calibration   "
#define L_CAL_STEER_AD  "Adjust to        deg"

#define L_CAL_ANGLE     "Angle calibration   "
#define L_CAL_ANGLE_AD  "Adjust to        deg"

#define L_CAL_KP        "PID adjust KP       "
#define L_CAL_KP_AD     "KP:                 "

#define L_CAL_KI        "PID adjust KI       "
#define L_CAL_KI_AD     "KI:                 "

#define L_CAL_KD        "PID adjust KD       "
#define L_CAL_KD_AD     "KD:                 "

#define L_CAL_OFFSET    "Adjust offset       "
#define L_CAL_OFFSET_AD "Offset :         deg"

#define L_CAL_QUAL      "Correct RTK ident.  "
#define L_CAL_QUAL_AD   "Quality:            "

#define L_CAL_SPEED     "Speed calibration   "
#define L_CAL_SPEED_AD  "Accelerate to 10kph "

#define L_CAL_GPS       "GPS autodetect      "
#define L_CAL_GPS_DONE  "passed              "
#define L_CAL_GPS_FAIL  "failed...           "
#define L_CAL_GPS_M1    "Check cabling and   "
#define L_CAL_GPS_M2    "nmea output         "

#define L_CAL_COMPLETE  "Finish calibration  "
#define L_CAL_NOSAVE    "Data NOT saved      "
#define L_CAL_DDONE     "done                "
#define L_CAL_SAVE      "Data saved          "

// ---------------
// Taal NEDERLANDS
// ---------------
#elif defined NEDERLANDS

const char L_BLANK           [] PROGMEM = "                    ";

const char  L_MEIJWORKS      [] PROGMEM = "     MeijWorks      ";
const char  L_DEVICE         [] PROGMEM = "Sprayercontrol  v0.1";
const char  L_COPYRIGHT      [] PROGMEM = "      (c) 2014      ";
const char  L_AUTHOR         [] PROGMEM = "  by J.A. Woltjer   ";

const char  L_FLOW           [] PROGMEM = "Afgifte:        L/Ha";
const char  L_MEASURE        [] PROGMEM = "Gemeten:        L/Ha";
const char  L_SPEED          [] PROGMEM = "Snelheid:       KM/h";
const char  L_SETPOINT       [] PROGMEM = "Setpoint:           ";

const char  L_MEN_ACCEPT     [] PROGMEM = "+ : accepteren      ";
const char  L_MEN_NEXT       [] PROGMEM = "- : volgende        ";

const char  L_MEN_SIM        [] PROGMEM = "SIM instellingen    ";
const char  L_MEN_SPRAYER    [] PROGMEM = "SPRAYER instellingen";
const char  L_MEN_PID        [] PROGMEM = "PID instellingen    ";
const char  L_MEN_CAL_TRACTOR[] PROGMEM = "Calibreer tractor   ";
const char  L_MEN_CAL_SPRAYER[] PROGMEM = "Calibreer sprayer   ";

const char  L_MEN_STORE      [] PROGMEM = "Return              ";

const char  L_CAL_ACCEPT     [] PROGMEM = "+ : accepteren      ";
const char  L_CAL_DECLINE    [] PROGMEM = "- : annuleren       ";

const char  L_CAL_DONE       [] PROGMEM = "voltooid            ";
const char  L_CAL_DECLINED   [] PROGMEM = "geannuleerd         ";

const char  L_CAL_ADJUST     [] PROGMEM = "+ / - : verstellen  ";
const char  L_CAL_ENTER      [] PROGMEM = "Beide : accepteren  ";

const char  L_CAL_ON         [] PROGMEM = "                 aan";
const char  L_CAL_OFF        [] PROGMEM = "                 uit";

const char  L_CAL_SIM        [] PROGMEM = "Wijzig sim mode     ";

const char  L_CAL_SIMS       [] PROGMEM = "Wijzig sim snelheid ";
const char  L_CAL_SIMS_AD    [] PROGMEM = "Huidig:          kmh";

const char  L_CAL_SIMT       [] PROGMEM = "Wijzig sim tijd     ";
const char  L_CAL_SIMT_AD    [] PROGMEM = "Huidig:          sec";

const char  L_CAL_SPEED      [] PROGMEM = "Snelheids calibratie";
const char  L_CAL_SPEED_AD   [] PROGMEM = "Gem. pulsen:        ";

const char  L_CAL_TEETH      [] PROGMEM = "Wijzig aantal tanden";
const char  L_CAL_TEETH_AD   [] PROGMEM = "Huidig aantal:      ";

const char  L_CAL_PUMPS      [] PROGMEM = "Wijzig aantal pompen";
const char  L_CAL_PUMPS_AD   [] PROGMEM = "Huidig aantal:      ";

const char  L_CAL_WIDTH      [] PROGMEM = "Wijzig werkbreedte  ";
const char  L_CAL_WIDTH_AD   [] PROGMEM = "Huidige breedte:    ";

const char  L_CAL_FLOW       [] PROGMEM = "Flow calibratie     ";
const char  L_CAL_FLOW_AD    [] PROGMEM = "Huidig:           cc";

const char  L_CAL_PWM        [] PROGMEM = "PWM calibratie      ";
const char  L_CAL_PWM_AD     [] PROGMEM = "Stap:               ";

const char  L_CAL_KP         [] PROGMEM = "PID wijzig KP       ";
const char  L_CAL_KP_AD      [] PROGMEM = "KP:                 ";

const char  L_CAL_KI         [] PROGMEM = "PID wijzig KI       ";
const char  L_CAL_KI_AD      [] PROGMEM = "KI:                 ";

const char  L_CAL_KD         [] PROGMEM = "PID wijzig KD       ";
const char  L_CAL_KD_AD      [] PROGMEM = "KD:                 ";

const char  L_CAL_COMPLETE   [] PROGMEM = "Calibratie afronden ";
const char  L_CAL_NOSAVE     [] PROGMEM = "Data NIET opgeslagen";
const char  L_CAL_DDONE      [] PROGMEM = "geslaagd            ";
const char  L_CAL_SAVE       [] PROGMEM = "Data is opgeslagen  ";

// ----------
// Taal Deens
// ----------
#elif defined DANSK

#define L_BLANK         "                    "

#define L_MEIJWORKS     "     MeijWorks      "
#define L_DEVICE        "  Plovstyring v0.74 "
#define L_COPYRIGHT     "      (c) 2013      "
#define L_AUTHOR        "    J.A. Woltjer    "

#define L_WIDTH         "Arbejdsbredde:      "
#define L_A_WIDTH       "Aktuelle bredde:    "
#define L_SLIP          "Slip:              %"
#define L_ANGLE           "ANGLE:                "

#define L_CAL_ACCEPT    "+ : acceptere       "
#define L_CAL_DECLINE   "- : annullere       "

#define L_CAL_DONE      "f�rdig              "
#define L_CAL_DECLINED  "annulleret          "

#define L_CAL_ADJUST    "+ / - : justere     "
#define L_CAL_ENTER     "Beide : acceptere   "

#define L_CAL_WIDTH     "Bredde kalibrering  "
#define L_CAL_WIDTH_AD  "Justere til       cm"

#define L_CAL_SHARES    "�ndre antal plovjern"
#define L_CAL_SHARES_AD "Antal plovjern :    "

#define L_CAL_MARGIN    "�ndre fejlmargen    "
#define L_CAL_MARGIN_AD "Fejlmargen :      cm"

#define L_CAL_MAXCOR    "�ndre correction    "
#define L_CAL_MAXCOR_AD "Max cor:          cm"

#define L_CAL_SIDE      "Corrigeer ploegzijde"
#define L_CAL_SIDE_AD   "Ploegt nu naar:     "

#define L_CAL_QUAL      "Corrigeer RTK ident."
#define L_CAL_QUAL_AD   "Quality:            "

#define L_CAL_SPEED     "Snelheids calibratie"
#define L_CAL_SPEED_AD  "Accelereer tot 10kmh"

#define L_CAL_GPS       "GPS autodetect      "
#define L_CAL_GPS_DONE  "succesfuld          "
#define L_CAL_GPS_FAIL  "mislykket...        "
#define L_CAL_GPS_M1    "Kontrollere kabler  "
#define L_CAL_GPS_M2    "og nmea output      "

#define L_CAL_COMPLETE  "Kalibrering f�rdig  "
#define L_CAL_DDONE     "f�rdig              "
#define L_CAL_NOSAVE    "Data IKKE er gemt   "
#define L_CAL_SAVE      "Data gemt           "

#endif

#endif
